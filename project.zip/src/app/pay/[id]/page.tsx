'use client';

import { useParams } from 'next/navigation';
import { useState, useEffect } from 'react';
import { AppNavbar } from "@/components/AppNavbar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { CreditCard, ArrowLeft, Zap, ShieldCheck, Copy, CheckCircle2, QrCode, Info } from "lucide-react";
import Link from "next/link";
import Image from "next/image";
import { mockMatches } from "@/lib/mock-data";
import { useToast } from "@/hooks/use-toast";

export default function PaymentPage() {
  const params = useParams();
  const { toast } = useToast();
  const [copied, setCopied] = useState(false);
  const [amount, setAmount] = useState<string>("50");
  const [qrUrl, setQrUrl] = useState<string>("");
  
  const matchId = params.id as string;
  const match = mockMatches.find(m => m.id === matchId);

  const UPI_ID = "9765617861@fam";
  const RECEIVER_NAME = "FireDash Tournament";
  const MIN_AMOUNT = 15;
  const MAX_AMOUNT = 500;

  useEffect(() => {
    const validAmount = parseFloat(amount);
    if (!isNaN(validAmount) && validAmount >= MIN_AMOUNT && validAmount <= MAX_AMOUNT) {
      const upiUrl = `upi://pay?pa=${UPI_ID}&pn=${encodeURIComponent(RECEIVER_NAME)}&am=${amount}&cu=INR&tn=${encodeURIComponent("Match Entry: " + (match?.tournamentName || "Entry Fee"))}`;
      setQrUrl(`https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(upiUrl)}`);
    } else {
      // Keep showing a QR for the fallback or empty state if invalid
      setQrUrl("");
    }
  }, [amount, match?.tournamentName]);

  if (!match) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <p className="text-xl font-headline font-bold">Match data not found.</p>
      </div>
    );
  }

  const handleCopyUpi = () => {
    navigator.clipboard.writeText(UPI_ID);
    setCopied(true);
    toast({
      title: "UPI ID Copied",
      description: "You can now paste it in your payment app.",
    });
    setTimeout(() => setCopied(false), 2000);
  };

  const handleUpiPayment = () => {
    const numAmount = parseFloat(amount);
    if (isNaN(numAmount) || numAmount < MIN_AMOUNT || numAmount > MAX_AMOUNT) {
      toast({
        variant: "destructive",
        title: "Invalid Amount",
        description: `Please enter an amount between ₹${MIN_AMOUNT} and ₹${MAX_AMOUNT}`,
      });
      return;
    }
    const upiUrl = `upi://pay?pa=${UPI_ID}&pn=${encodeURIComponent(RECEIVER_NAME)}&am=${amount}&cu=INR&tn=${encodeURIComponent("Match Entry: " + match.tournamentName)}`;
    window.location.href = upiUrl;
  };

  const isAmountValid = () => {
    const num = parseFloat(amount);
    return !isNaN(num) && num >= MIN_AMOUNT && num <= MAX_AMOUNT;
  };

  return (
    <div className="pb-24 pt-8 md:pt-24 min-h-screen bg-background flex flex-col items-center">
      <AppNavbar />
      
      <div className="container max-w-md mx-auto px-4 mt-10 animate-fade-in">
        <Link href="/matches" className="flex items-center gap-2 text-muted-foreground hover:text-primary mb-6 transition-colors group">
          <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" /> 
          <span className="text-sm font-bold uppercase tracking-wider">Back to Matches</span>
        </Link>
        
        <Card className="neon-border bg-card/50 backdrop-blur-md shadow-2xl border-primary/20 overflow-hidden">
          <div className="h-2 bg-gradient-to-r from-primary via-secondary to-primary animate-pulse" />
          
          <CardHeader className="text-center pt-8 pb-4">
            <CardTitle className="text-3xl font-headline font-bold tracking-tighter">SECURE PAYMENT</CardTitle>
            <CardDescription className="text-muted-foreground uppercase text-[10px] font-bold tracking-[0.2em] mt-2">
              Instant Tournament Registration
            </CardDescription>
          </CardHeader>
          
          <CardContent className="space-y-6 pb-10 px-8">
            {/* QR Code Section */}
            <div className="flex flex-col items-center justify-center p-6 bg-white rounded-2xl border-4 border-primary/20 shadow-xl">
              {qrUrl ? (
                <div className="relative w-[200px] h-[200px]">
                  <Image 
                    src={qrUrl} 
                    alt="Payment QR Code" 
                    width={200} 
                    height={200}
                    className="rounded-lg"
                  />
                </div>
              ) : (
                <div className="w-[200px] h-[200px] bg-muted flex items-center justify-center rounded-lg border-2 border-dashed">
                  <QrCode className="w-12 h-12 text-muted-foreground opacity-20" />
                </div>
              )}
              <p className="text-black text-[10px] font-bold mt-4 flex items-center gap-1">
                <ShieldCheck className="w-3 h-3 text-green-600" /> SCAN TO PAY INSTANTLY
              </p>
            </div>

            {/* Amount Input */}
            <div className="space-y-3">
              <Label htmlFor="amount" className="text-xs font-bold text-muted-foreground uppercase tracking-widest block ml-1">
                Enter Entry Fee Amount
              </Label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-primary font-bold">₹</span>
                <Input 
                  id="amount"
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="pl-8 h-14 bg-background border-border text-lg font-bold"
                  placeholder="0.00"
                />
              </div>
              <div className="flex items-center gap-2 px-1">
                <Info className="w-3 h-3 text-muted-foreground" />
                <p className="text-[10px] text-muted-foreground font-medium">
                  Allowed: ₹{MIN_AMOUNT} - ₹{MAX_AMOUNT}
                </p>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-muted/20 border border-border/50">
              <div className="flex justify-between items-center mb-1">
                <span className="text-[10px] text-muted-foreground uppercase font-bold tracking-wider">Tournament</span>
                <span className="text-xs font-bold text-primary truncate max-w-[150px]">{match.tournamentName}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-[10px] text-muted-foreground uppercase font-bold tracking-wider">UPI ID</span>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-code">{UPI_ID}</span>
                  <button onClick={handleCopyUpi} className="text-primary hover:text-primary/80">
                    {copied ? <CheckCircle2 className="w-3 h-3 text-green-500" /> : <Copy className="w-3 h-3" />}
                  </button>
                </div>
              </div>
            </div>

            <Button 
              onClick={handleUpiPayment}
              disabled={!isAmountValid()}
              className="w-full h-16 text-lg font-headline font-bold bg-primary hover:bg-primary/90 text-white shadow-lg shadow-primary/20 neon-glow transition-all rounded-xl group disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Zap className="w-6 h-6 mr-2 group-hover:scale-110 transition-transform" /> 
              PAY ₹{isAmountValid() ? amount : '---'} NOW
            </Button>
            
            <p className="text-[9px] text-muted-foreground/60 text-center px-4">
              By paying, you agree to the tournament rules. Please take a screenshot of the success screen for manual verification if needed.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}