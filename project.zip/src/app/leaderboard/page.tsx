import { AppNavbar } from "@/components/AppNavbar";
import { mockTeams } from "@/lib/mock-data";
import { BarChart3, TrendingUp, Medal, Zap } from "lucide-react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import Image from "next/image";

export default function LeaderboardPage() {
  return (
    <div className="pb-24 pt-8 md:pt-24">
      <AppNavbar />
      
      <div className="container mx-auto px-4">
        <header className="mb-12 text-center max-w-2xl mx-auto">
          <div className="inline-flex p-3 rounded-2xl bg-primary/10 border border-primary/20 mb-4 neon-glow">
            <BarChart3 className="w-6 h-6 text-primary" />
          </div>
          <h1 className="text-4xl font-headline font-bold">HALL OF CHAMPIONS</h1>
          <p className="text-muted-foreground mt-2">Real-time performance rankings across the entire FireDash league.</p>
        </header>

        {/* Top 3 Podium View */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16 items-end">
          {/* Second Place */}
          <div className="order-2 md:order-1 flex flex-col items-center">
            <div className="relative mb-4">
              <div className="absolute -top-4 -left-4 w-8 h-8 rounded-full bg-slate-400 flex items-center justify-center font-bold text-white z-10 shadow-lg">2</div>
              <Image src={mockTeams[1].logo} alt={mockTeams[1].name} width={120} height={120} className="rounded-full border-4 border-slate-400 p-1" />
            </div>
            <div className="text-center bg-card p-4 rounded-xl border border-border w-full">
              <h3 className="font-headline font-bold text-lg">{mockTeams[1].name}</h3>
              <p className="text-primary font-bold">{mockTeams[1].points} PTS</p>
            </div>
          </div>

          {/* First Place */}
          <div className="order-1 md:order-2 flex flex-col items-center">
            <div className="relative mb-6">
              <Medal className="w-10 h-10 text-yellow-400 absolute -top-12 left-1/2 -translate-x-1/2 animate-bounce" />
              <div className="absolute -top-4 -left-4 w-10 h-10 rounded-full bg-yellow-400 flex items-center justify-center font-bold text-black z-10 shadow-xl border-4 border-background">1</div>
              <Image src={mockTeams[0].logo} alt={mockTeams[0].name} width={160} height={160} className="rounded-full border-4 border-yellow-400 p-2 neon-glow shadow-yellow-400/20" />
            </div>
            <div className="text-center bg-primary/10 p-6 rounded-2xl border border-primary/30 w-full neon-border">
              <h3 className="font-headline font-bold text-2xl">{mockTeams[0].name}</h3>
              <p className="text-primary text-xl font-bold">{mockTeams[0].points} PTS</p>
              <Badge className="bg-primary mt-2">CURRENT CHAMPION</Badge>
            </div>
          </div>

          {/* Third Place */}
          <div className="order-3 flex flex-col items-center">
            <div className="relative mb-4">
              <div className="absolute -top-4 -left-4 w-8 h-8 rounded-full bg-amber-700 flex items-center justify-center font-bold text-white z-10 shadow-lg">3</div>
              <Image src={mockTeams[2].logo} alt={mockTeams[2].name} width={120} height={120} className="rounded-full border-4 border-amber-700 p-1" />
            </div>
            <div className="text-center bg-card p-4 rounded-xl border border-border w-full">
              <h3 className="font-headline font-bold text-lg">{mockTeams[2].name}</h3>
              <p className="text-primary font-bold">{mockTeams[2].points} PTS</p>
            </div>
          </div>
        </div>

        {/* Detailed Leaderboard Table */}
        <div className="bg-card rounded-2xl border border-border overflow-hidden shadow-2xl">
          <Table>
            <TableHeader className="bg-muted/50">
              <TableRow className="hover:bg-transparent">
                <TableHead className="w-[100px] font-headline text-xs uppercase tracking-wider">Rank</TableHead>
                <TableHead className="font-headline text-xs uppercase tracking-wider">Team Name</TableHead>
                <TableHead className="font-headline text-xs uppercase tracking-wider text-right">Points</TableHead>
                <TableHead className="font-headline text-xs uppercase tracking-wider text-right">Trend</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {mockTeams.map((team, index) => (
                <TableRow key={team.id} className="border-border/50 hover:bg-primary/5 transition-colors cursor-pointer">
                  <TableCell className="font-bold text-lg">#{index + 1}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-3">
                      <Image src={team.logo} alt={team.name} width={32} height={32} className="rounded-md" />
                      <span className="font-bold font-headline">{team.name}</span>
                    </div>
                  </TableCell>
                  <TableCell className="text-right font-code text-primary font-bold">{team.points}</TableCell>
                  <TableCell className="text-right">
                    <div className="flex items-center justify-end gap-1 text-green-500 text-xs font-bold">
                      <TrendingUp className="w-4 h-4" /> +12
                    </div>
                  </TableCell>
                </TableRow>
              ))}
              {/* Add dummy rows for scale */}
              {Array.from({ length: 5 }).map((_, i) => (
                <TableRow key={i} className="border-border/50 opacity-50">
                  <TableCell className="font-bold text-lg">#{mockTeams.length + i + 1}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-md bg-muted animate-pulse"></div>
                      <span className="font-headline">Quantum Seekers {i+1}</span>
                    </div>
                  </TableCell>
                  <TableCell className="text-right font-code">{800 - (i * 50)}</TableCell>
                  <TableCell className="text-right">
                     <div className="flex items-center justify-end gap-1 text-muted-foreground text-xs">
                       <Zap className="w-4 h-4" /> 0
                     </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </div>
    </div>
  );
}