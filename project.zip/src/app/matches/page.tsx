import { AppNavbar } from "@/components/AppNavbar";
import { MatchCard } from "@/components/MatchCard";
import { AINarrativeSection } from "@/components/AINarrativeSection";
import { mockMatches } from "@/lib/mock-data";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Calendar, Filter, Search } from "lucide-react";
import { Input } from "@/components/ui/input";

export default function MatchesPage() {
  return (
    <div className="pb-24 pt-8 md:pt-24">
      <AppNavbar />
      
      <div className="container mx-auto px-4">
        <header className="mb-8">
          <h1 className="text-4xl font-headline font-bold flex items-center gap-3">
            <Calendar className="w-8 h-8 text-primary" /> MATCH CALENDAR
          </h1>
          <p className="text-muted-foreground">Interactive tournament schedule and rivalry insights.</p>
        </header>

        <div className="flex flex-col md:flex-row gap-4 mb-8">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input className="pl-10 bg-card border-border" placeholder="Search teams or tournaments..." />
          </div>
          <div className="flex gap-2">
            <Tabs defaultValue="all" className="w-full md:w-auto">
              <TabsList className="bg-card border border-border">
                <TabsTrigger value="all">All Matches</TabsTrigger>
                <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
                <TabsTrigger value="live">Live</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
        </div>

        <div className="space-y-12">
          {mockMatches.map((match, index) => (
            <div key={match.id} className="space-y-8 animate-fade-in" style={{ animationDelay: `${index * 100}ms` }}>
              <MatchCard match={match} />
              
              <div className="px-2">
                <div className="flex items-center gap-2 mb-4">
                  <div className="h-px bg-border flex-1"></div>
                  <span className="text-xs font-bold text-primary uppercase tracking-widest px-2">AI Insights</span>
                  <div className="h-px bg-border flex-1"></div>
                </div>
                <AINarrativeSection match={match} />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}