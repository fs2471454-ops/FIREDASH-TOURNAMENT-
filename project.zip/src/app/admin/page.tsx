import { AppNavbar } from "@/components/AppNavbar";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { LayoutDashboard, Plus, Settings, Users, Shield, Save, Trash2, Edit } from "lucide-react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { mockMatches } from "@/lib/mock-data";

export default function AdminPage() {
  return (
    <div className="pb-24 pt-8 md:pt-24">
      <AppNavbar />
      
      <div className="container mx-auto px-4">
        <header className="mb-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-4xl font-headline font-bold flex items-center gap-3">
              <LayoutDashboard className="w-8 h-8 text-primary" /> COMMAND HUB
            </h1>
            <p className="text-muted-foreground">Advanced match control and league management.</p>
          </div>
          <Button className="bg-primary hover:bg-primary/90 text-white font-headline rounded-sm neon-glow">
            <Plus className="w-4 h-4 mr-2" /> CREATE NEW MATCH
          </Button>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Quick Actions Sidebar */}
          <div className="lg:col-span-1 space-y-6">
            <Card className="bg-card border-border shadow-xl">
              <CardHeader>
                <CardTitle className="text-sm font-headline uppercase tracking-wider">System Controls</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 p-3">
                {[
                  { label: 'Manage Participants', icon: Users },
                  { label: 'Security Protocols', icon: Shield },
                  { label: 'Platform Settings', icon: Settings },
                ].map((action, i) => (
                  <Button key={i} variant="ghost" className="w-full justify-start text-muted-foreground hover:text-primary hover:bg-primary/5">
                    <action.icon className="w-4 h-4 mr-3" />
                    {action.label}
                  </Button>
                ))}
              </CardContent>
            </Card>

            <Card className="bg-primary/5 border-primary/20">
              <CardContent className="p-6">
                <h3 className="font-headline font-bold text-sm text-primary mb-2">NETWORK STATUS</h3>
                <div className="flex items-center gap-2 mb-4">
                  <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
                  <span className="text-xs font-bold text-green-500">OPERATIONAL</span>
                </div>
                <div className="space-y-2 text-xs text-muted-foreground">
                  <div className="flex justify-between">
                    <span>Server Latency</span>
                    <span className="text-primary font-code">24ms</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Active Sessions</span>
                    <span className="text-primary font-code">1,242</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Management View */}
          <div className="lg:col-span-3 space-y-6">
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="font-headline">ACTIVE TOURNAMENT PIPELINE</CardTitle>
                <CardDescription>Update results, edit rosters, or cancel scheduled events.</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="rounded-md border border-border overflow-hidden">
                  <Table>
                    <TableHeader className="bg-muted/50">
                      <TableRow>
                        <TableHead className="font-headline text-xs">MATCH ID</TableHead>
                        <TableHead className="font-headline text-xs">PARTICIPANTS</TableHead>
                        <TableHead className="font-headline text-xs">STATUS</TableHead>
                        <TableHead className="font-headline text-xs text-right">ACTIONS</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {mockMatches.map((match) => (
                        <TableRow key={match.id} className="border-border/50">
                          <TableCell className="font-code text-xs text-muted-foreground">{match.id}</TableCell>
                          <TableCell className="font-bold">
                            <span className="text-primary">{match.teamA.name}</span>
                            <span className="mx-2 text-muted-foreground">vs</span>
                            <span className="text-secondary">{match.teamB.name}</span>
                          </TableCell>
                          <TableCell>
                            <span className="inline-flex items-center px-2 py-1 rounded-md bg-yellow-400/10 text-yellow-400 text-[10px] font-bold border border-yellow-400/20 uppercase">
                              Scheduled
                            </span>
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-2">
                              <Button variant="outline" size="icon" className="h-8 w-8 text-muted-foreground">
                                <Edit className="h-4 w-4" />
                              </Button>
                              <Button variant="outline" size="icon" className="h-8 w-8 text-destructive border-destructive/20 hover:bg-destructive/10">
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>

            {/* Quick Match Creator Form */}
            <Card className="bg-card border-border neon-border">
              <CardHeader>
                <CardTitle className="font-headline flex items-center gap-2">
                  <Zap className="w-5 h-5 text-primary" /> RAPID DEPLOYMENT
                </CardTitle>
                <CardDescription>Quickly spin up a localized match for community events.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-muted-foreground uppercase">Tournament Name</label>
                    <Input className="bg-background border-border" placeholder="e.g. Scrimmage Alpha" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-muted-foreground uppercase">Match Date</label>
                    <Input type="datetime-local" className="bg-background border-border text-foreground" />
                  </div>
                </div>
                <Button className="w-full bg-primary hover:bg-primary/90">
                  <Save className="w-4 h-4 mr-2" /> BROADCAST EVENT
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}