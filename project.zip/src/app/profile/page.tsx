import { AppNavbar } from "@/components/AppNavbar";
import { mockPlayers } from "@/lib/mock-data";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { User, Target, Trophy, Clock, Zap, Shield, BarChart2 } from "lucide-react";
import Image from "next/image";

export default function ProfilePage() {
  const player = mockPlayers[0];

  return (
    <div className="pb-24 pt-8 md:pt-24">
      <AppNavbar />
      
      <div className="container mx-auto px-4 max-w-4xl">
        {/* Header Profile Card */}
        <div className="relative mb-12">
          <div className="h-48 rounded-3xl bg-gradient-to-r from-primary/30 to-secondary/30 relative overflow-hidden border border-border">
             <div className="absolute inset-0 bg-[url('https://picsum.photos/seed/bg/1200/600')] opacity-10 bg-cover mix-blend-overlay"></div>
          </div>
          <div className="px-8 -mt-16 flex flex-col md:flex-row items-end gap-6 relative z-10">
            <div className="relative group">
              <div className="absolute inset-0 bg-primary/20 rounded-2xl blur-2xl group-hover:bg-primary/40 transition-all"></div>
              <Image 
                src={player.avatar} 
                alt={player.name} 
                width={160} 
                height={160} 
                className="rounded-2xl border-4 border-background relative z-10 shadow-2xl"
              />
              <div className="absolute -bottom-2 -right-2 bg-primary text-white p-2 rounded-lg z-20 neon-glow">
                <Shield className="w-5 h-5" />
              </div>
            </div>
            <div className="flex-1 pb-4">
              <h1 className="text-4xl font-headline font-bold mb-2">{player.name}</h1>
              <div className="flex flex-wrap gap-3">
                <Badge className="bg-primary/20 text-primary border-primary/30 hover:bg-primary/30">ELITE STRIKER</Badge>
                <Badge variant="outline" className="text-muted-foreground">LVL 72</Badge>
                <Badge variant="outline" className="text-muted-foreground font-code tracking-tighter uppercase">Team Alpha</Badge>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Quick Stats */}
          <Card className="md:col-span-1 bg-card/50 border-border">
            <CardHeader className="pb-2">
              <CardTitle className="text-xs uppercase tracking-widest text-primary flex items-center gap-2">
                <BarChart2 className="w-4 h-4" /> Career Dossier
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6 pt-4">
              <div className="flex justify-between items-center p-3 rounded-lg bg-background border border-border">
                <div className="flex items-center gap-2">
                  <Target className="w-4 h-4 text-primary" />
                  <span className="text-sm">K/D Ratio</span>
                </div>
                <span className="font-bold text-xl font-code">{player.kdRatio}</span>
              </div>
              <div className="flex justify-between items-center p-3 rounded-lg bg-background border border-border">
                <div className="flex items-center gap-2">
                  <Trophy className="w-4 h-4 text-yellow-400" />
                  <span className="text-sm">Total Wins</span>
                </div>
                <span className="font-bold text-xl font-code">{player.wins}</span>
              </div>
              <div className="flex justify-between items-center p-3 rounded-lg bg-background border border-border">
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-secondary" />
                  <span className="text-sm">Hours Played</span>
                </div>
                <span className="font-bold text-xl font-code">1,248</span>
              </div>
            </CardContent>
          </Card>

          {/* Main Content */}
          <div className="md:col-span-2 space-y-6">
            {/* Preferred Loadout */}
            <Card className="bg-card/50 border-border">
              <CardHeader>
                <CardTitle className="text-sm uppercase tracking-widest text-secondary flex items-center gap-2">
                  <Zap className="w-4 h-4" /> Combat Loadout
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-4">
                  <div className="w-full p-4 rounded-xl bg-primary/5 border border-primary/20 flex items-center gap-4">
                    <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                      <Target className="w-6 h-6 text-primary" />
                    </div>
                    <div>
                      <h4 className="font-headline font-bold">{player.preferredLoadout}</h4>
                      <p className="text-xs text-muted-foreground">Signature tactical setup</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Tournament History */}
            <Card className="bg-card/50 border-border">
              <CardHeader>
                <CardTitle className="text-sm uppercase tracking-widest text-primary flex items-center gap-2">
                  <Trophy className="w-4 h-4" /> Tournament History
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {player.history.map((item, i) => (
                  <div key={i} className="flex items-center gap-4 p-4 rounded-xl bg-background border border-border hover:border-primary/30 transition-all cursor-default">
                    <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center text-primary font-bold">
                      {i + 1}
                    </div>
                    <div className="flex-1">
                      <p className="font-medium">{item}</p>
                      <p className="text-xs text-muted-foreground">Verified achievement</p>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}